package dream.org.android001.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import cn.pedant.SweetAlert.SweetAlertDialog;
import dream.org.android001.R;
import dream.org.android001.bean.account.Account;
import dream.org.android001.bean.common.CommonConstants;
import dream.org.android001.bean.response.ResponseBean;
import dream.org.android001.common.VolleyApplication;
import dream.org.android001.service.account.AccountService;
import dream.org.android001.service.common.IRequestCallback;
import dream.org.android001.service.common.ServiceUrlConfig;
import dream.org.android001.util.photo.PhotoUtils;
import dream.org.android001.view.SelectPicPopupWindow;

public class MeActivity extends Activity implements View.OnClickListener {
    private static final int PHOTO_REQUEST_TAKEPHOTO = 1;// 拍照
    private static final int PHOTO_REQUEST_GALLERY = 2;// 从相册中选择
    private static final int PHOTO_REQUEST_CUT = 3;// 结果
    private AccountService accountService = VolleyApplication.getInstance().getAccountService();
    private TextView txtNickname;
    private NetworkImageView imgHead;
    private SelectPicPopupWindow menuWindow;
    private TextView txtCover;
    private String token;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me);
        txtNickname = (TextView) findViewById(R.id.txt_fragment_me_nickname);
        imgHead = (NetworkImageView) findViewById(R.id.img_fragment_me_head);
        imgHead.setOnClickListener(this);
        txtCover = (TextView) findViewById(R.id.txt_fragment_me_cover);
        btnLogout=(Button)findViewById(R.id.btn_fragment_me_logout);
        btnLogout.setOnClickListener(this);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        token = bundle.get(CommonConstants.ACCESS_TOKEN).toString();
        getAccountInfo(token);
    }

    /**
     * 获取账户信息
     *
     * @param accessToken
     */
    private void getAccountInfo(String accessToken) {
        accountService.getAccountInfo(accessToken, new IRequestCallback<ResponseBean<Account>>() {
            @Override
            public void onSuccess(ResponseBean<Account> responseBean) {
                if (responseBean != null) {
                    if (responseBean.getRes().equals("0") && responseBean.getData() != null) {
                        txtNickname.setText(responseBean.getData().nickName);
                        imgHead.setDefaultImageResId(R.drawable.head);
                        imgHead.setErrorImageResId(R.drawable.ic_launcher);
                        imgHead.setImageUrl(ServiceUrlConfig.IMG_URL+responseBean.getData().imgUrl, VolleyApplication.getInstance()
                                .getImageLoader());

                        new SweetAlertDialog(MeActivity.this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("登录成功!")
                                .setContentText(responseBean.getData().nickName)
                                .show();
                    } else {
                        Toast.makeText(MeActivity.this, responseBean.getMsg(), Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onFail(VolleyError error) {
                System.out.println(error.getStackTrace().toString());
                new SweetAlertDialog(MeActivity.this, SweetAlertDialog.ERROR_TYPE)
                        .setTitleText(CommonConstants.SERVER_ERROR)
                        .show();
            }
        }, VolleyApplication.getInstance().getRequestQueue());
    }

    private void logout(String accessToken){
        accountService.logout(accessToken, new IRequestCallback<ResponseBean<Object>>() {
            @Override
            public void onSuccess(ResponseBean<Object> responseBean) {
                if (responseBean != null) {
                    if (responseBean.getRes().equals("0")) {
                        new SweetAlertDialog(MeActivity.this, SweetAlertDialog.SUCCESS_TYPE)
                                .setTitleText("注销成功!")
                                .show();
                    } else {
                        Toast.makeText(MeActivity.this, responseBean.getMsg(), Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onFail(VolleyError error) {
                System.out.println(error.getStackTrace().toString());
                new SweetAlertDialog(MeActivity.this, SweetAlertDialog.ERROR_TYPE)
                        .setTitleText(CommonConstants.SERVER_ERROR)
                        .show();
            }
        }, VolleyApplication.getInstance().getRequestQueue());
    }

    /**
     * 更换头像
     */
    private void choosePhoto() {
        txtCover.setVisibility(View.VISIBLE);
        //实例化SelectPicPopupWindow
        menuWindow = new SelectPicPopupWindow(MeActivity.this, this);
        //显示窗口
        menuWindow.showAtLocation(MeActivity.this.findViewById(R.id.relativeLayout_me), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0); //设置layout在PopupWindow中显示的位置
        menuWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                txtCover.setVisibility(View.INVISIBLE);
            }
        });
    }

    /**
     * 拍照
     */
    private void takePhoto() {
        Intent cameraIntent = new Intent(
                MediaStore.ACTION_IMAGE_CAPTURE);
        // 指定调用相机拍照后照片的储存路径
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                Uri.fromFile(PhotoUtils.getTempImageFile()));
        startActivityForResult(cameraIntent,
                PHOTO_REQUEST_TAKEPHOTO);
    }

    /**
     * 从相册选择
     */
    private void pickPhoto() {
        Intent getAlbum = new Intent(Intent.ACTION_GET_CONTENT);
        getAlbum.setType("image/*");
        startActivityForResult(getAlbum, PHOTO_REQUEST_GALLERY);
    }

    // 封装请求Gallery的intent
    public Intent getPhotoPickIntent() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT, null);
        intent.setType("image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", 80);
        intent.putExtra("outputY", 80);
        intent.putExtra("return-data", true);
        return intent;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case PHOTO_REQUEST_TAKEPHOTO:// 当选择拍照时调用
                startPhotoZoom(Uri.fromFile(PhotoUtils.getTempImageFile()));
                break;
            case PHOTO_REQUEST_GALLERY:// 当选择从本地获取图片时
                // 做非空判断，当我们觉得不满意想重新剪裁的时候便不会报异常，下同
                if (data != null) {
                    System.out.println("11================");
                    startPhotoZoom(data.getData());
                } else {
                    System.out.println("================");
                }
                break;
            case PHOTO_REQUEST_CUT:// 返回的结果
                if (data != null) {
                    System.out.println("33================");
                    final Bitmap bitmap = data.getParcelableExtra("data");
                    accountService.modifyHeadImg(token, handler, bitmap);
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * 图片剪裁
     *
     * @param uri
     */
    private void startPhotoZoom(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        // crop为true是设置在开启的intent中设置显示的view可以剪裁
        intent.putExtra("crop", "true");

        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);

        // outputX,outputY 是剪裁图片的宽高
        intent.putExtra("outputX", 300);
        intent.putExtra("outputY", 300);
        intent.putExtra("return-data", true);
        intent.putExtra("noFaceDetection", true);
        System.out.println("22================");
        startActivityForResult(intent, PHOTO_REQUEST_CUT);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_fragment_me_head: {
                choosePhoto();
                break;
            }
            case R.id.btn_take_photo: {
                takePhoto();
                break;
            }
            case R.id.btn_pick_photo: {
                pickPhoto();
                break;
            }case R.id.btn_fragment_me_logout:{
                logout(token);
                break;
            }
        }
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Bundle data = msg.getData();
            ResponseBean<String> res = (ResponseBean<String>) data.get("value");
            if(res!=null){
                if(res.getRes().equals("0")){
                    imgHead.setDefaultImageResId(R.drawable.head);
                    imgHead.setErrorImageResId(R.drawable.ic_launcher);
                    imgHead.setImageUrl(ServiceUrlConfig.IMG_URL+res.getData(), VolleyApplication.getInstance()
                            .getImageLoader());
                    Log.i("mylog", "请求结果为-->" + ServiceUrlConfig.ACCOUNT_MODIFY_HEAD_IMG_URL+res.getData());
                }else{
                    Toast.makeText(MeActivity.this,res.getMsg(),Toast.LENGTH_LONG);
                }
            }
        }
    };
}
