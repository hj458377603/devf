package dream.org.android001.common;

import android.graphics.Bitmap;
import android.support.v4.util.LruCache;

import com.android.volley.toolbox.ImageLoader;

/**
 * Created by Administrator on 2015/4/28.
 */
public class MemoryCache implements ImageLoader.ImageCache {
    private LruCache<String, Bitmap> mCache;

    public MemoryCache() {
        int maxSize = (int) Runtime.getRuntime().maxMemory() / 8;
        mCache = new LruCache<String, Bitmap>(maxSize) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getHeight() * value.getRowBytes();
            }
        };
    }

    @Override
    public Bitmap getBitmap(String key) {
        return mCache.get(key);
    }

    @Override
    public void putBitmap(String key, Bitmap value) {
        mCache.put(key, value);
    }
}
