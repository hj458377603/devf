package dream.org.android001.common;

import android.app.Application;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;

import dream.org.android001.service.account.AccountService;

/**
 * Created by Administrator on 2015/4/27.
 */
public class VolleyApplication extends Application {
    private RequestQueue requestQueue;
    private static VolleyApplication instance;
    private ImageLoader imageLoader;
    private AccountService accountService;
    private Gson gson;

    public static VolleyApplication getInstance() {
        return instance;
    }

    public RequestQueue getRequestQueue() {
        return requestQueue;
    }

    public ImageLoader getImageLoader() {
        return imageLoader;
    }

    public AccountService getAccountService() {
        return accountService;
    }

    public Gson getGson() {
        return gson;
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onCreate() {
        // 初始化内存缓存目录
        File cacheDir = new File(
                android.os.Environment.getExternalStorageDirectory(),
                "volleyCache");
        /**
         * 初始化RequestQueue,其实这里你可以使用Volley.newRequestQueue来创建一个RequestQueue,
         * 直接使用构造函数可以定制我们需要的RequestQueue,比如线程池的大小等等
         */
        requestQueue = new RequestQueue(new DiskBasedCache(cacheDir),
                new BasicNetwork(new HurlStack()), 3);

        instance = this;

        // 初始化图片内存缓存
        MemoryCache mCache = new MemoryCache();
        // 初始化ImageLoader
        imageLoader = new ImageLoader(requestQueue, mCache);
        // 如果调用Volley.newRequestQueue,那么下面这句可以不用调用
        requestQueue.start();

        //初始化gson
        gson = new GsonBuilder().enableComplexMapKeySerialization().serializeNulls()
                .setDateFormat("yyyy-MM-dd HH:mm:ss").create();
        //初始化AccountService
        accountService = new AccountService();
    }
}
