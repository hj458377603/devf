package dream.org.android001.bean.account;

/**
 * Created by Administrator on 2015/4/26.
 */
public class Account {

}
