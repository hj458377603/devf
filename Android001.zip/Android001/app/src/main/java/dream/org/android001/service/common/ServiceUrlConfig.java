package dream.org.android001.service.common;

/**
 * Created by Administrator on 2015/4/26.
 */
public class ServiceUrlConfig {
    public static final String LOGIN_URL="http://localhost:8080/account/login";
}
