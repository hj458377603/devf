package dream.org.android001.service.common;

/**
 * Created by Administrator on 2015/4/26.
 */
public class ServiceUrlConfig {
    public static final String SERVER_URL="http://10.24.45.175:8080/web/";

    public static final String ACCOUNT_LOGIN_URL = SERVER_URL+"account/login";

    public static final String ACCOUNT_REG_URL = SERVER_URL+"account/register";

    public static final String ACCOUNT_INFO_URL=SERVER_URL+"account/private/getAccountInfo";

    public static final String ACCOUNT_MODIFY_HEAD_IMG_URL=SERVER_URL+"account/private/modifyHeadImg";

    public static final String ACCOUNT_LOGOUT_URL=SERVER_URL+"account/private/logout";

    public static final String IMG_URL=SERVER_URL+"img/";
}
