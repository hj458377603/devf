package dream.org.android001.util.photo;

import android.os.Environment;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Administrator on 2015/4/28.
 */
public class PhotoUtils {
    // 使用系统当前日期加以调整作为照片的名称
    public static String getPhotoFileName() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyyMMdd_HHmmss");
        return dateFormat.format(date) + ".jpg";
    }

    public static File getTempImageFile() {
        return new File(Environment.getExternalStorageDirectory(),
                getPhotoFileName());
    }
}
