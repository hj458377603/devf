package dream.org.android001.bean.common;

/**
 * Created by Administrator on 2015/4/27.
 */
public class CommonConstants {
    public static final String ACCESS_TOKEN = "ACCESS_TOKEN";

    public static final String SERVER_ERROR = "服务器异常";
}
