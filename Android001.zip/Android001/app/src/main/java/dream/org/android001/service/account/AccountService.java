package dream.org.android001.service.account;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.google.gson.reflect.TypeToken;

import dream.org.android001.bean.response.ResponseBean;
import dream.org.android001.service.common.BaseService;
import dream.org.android001.service.common.GsonRequest;
import dream.org.android001.service.common.IRequestCallback;
import dream.org.android001.service.common.ServiceUrlConfig;

/**
 * Created by Administrator on 2015/4/26.
 */
public class AccountService extends BaseService {
    public void login(String email, String pwd,
                      IRequestCallback<ResponseBean<String>> requestCallback,
                      RequestQueue queue) {
        String url = ServiceUrlConfig.LOGIN_URL;
        TypeToken<ResponseBean<String>> typeToken = new TypeToken<ResponseBean<String>>() {
        };

        GsonRequest<ResponseBean<String>> gsonRequest = new GsonRequest<ResponseBean<String>>(
                Request.Method.POST, url, requestCallback,
                initErrorListener(requestCallback), typeToken);
        queue.add(gsonRequest);
    }
}
